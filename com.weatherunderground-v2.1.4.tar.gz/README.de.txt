Diese App ruft die letzten Daten Ihrer persönlichen Wetterstation, die auf der Weather Underground Webseite gehostet wird, ab.
Eine 5-Tage-Vorhersage ist auch möglich.

Diese App kann die “Stations-ID” und “Ihren API-Schlüssel” nutzen. Diese Informationen finden Sie auf der Weather Underground Webseite unter “My Profile” im Bereich “Member Settings”. Die “Stations ID” befindet sich auf der Registerkarte “My Devices” und der “API Key” auf der Registerkarte “API Keys”.
Die App ruft einmal pro Minute die Informationen für Ihre Wetterstation von der Weather Underground Webseite ab. Die Webseite beschränkt die Anfragen auf 10 pro Minute und 1500 pro Tag, daher habe ich ein 1-Minuten-Intervall gewählt, damit sie den ganzen Tag laufen kann.

Zu den PWS-Daten gehören (vorausgesetzt die Daten werden von Ihrer Station zur Verfügung gestellt):

Aktuelle Temperatur
Gefühlte Temperatur
Taupunkt
Luftfeuchtigkeit
Luftdruck
Windrichtung
Windstärke
Regenmenge
Regenmenge, gesamt
UV Index
Sonnenstrahlung
Die prognostizierten Tagesdaten umfassen (für 5 Tage):

Mondphase
Regenmenge, gesamt
Schneemenge, gesamt
Höchsttemperatur
Tiefsttemperatur
Zusätzlich folgende Daten für Tag und Nacht (für 5 Tage):

Bewölkung
Niederschlagswahrscheinlichkeit
Niederschlagsart
Temperatur
Windrichtung
Windstärke
Luftfeuchtigkeit
UV Index