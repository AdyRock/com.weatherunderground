# Weather Underground

Get the last data from you personal weather station and tomorrows forecast. Each is a separate "device" so you can add either or both as you desire.

# Note: If anyone is interested in providing translations then I will be happy to add them in
